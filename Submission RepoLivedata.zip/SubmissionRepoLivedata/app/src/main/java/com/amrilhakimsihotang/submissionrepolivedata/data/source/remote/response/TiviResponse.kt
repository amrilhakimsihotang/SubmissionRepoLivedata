package com.amrilhakimsihotang.submissionrepolivedata.data.source.remote.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class TiviResponse(
        val id: String ,
        val original_name: String,
        val poster_path: String ,
        val overview: String ,
        val creatorcast: String ,
        val seriescast: String ,
        val writingcast: String
):Parcelable